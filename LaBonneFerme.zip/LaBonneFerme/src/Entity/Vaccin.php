<?php

namespace App\Entity;

use App\Repository\VaccinRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: VaccinRepository::class)]
class Vaccin
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $nom = null;

    #[ORM\Column(type: Types::DATE_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $dateVaccin = null;

    #[ORM\ManyToOne(inversedBy: 'vaccin')]
    private ?Animaux $animaux = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getDateVaccin(): ?\DateTimeInterface
    {
        return $this->dateVaccin;
    }

    public function setDateVaccin(?\DateTimeInterface $dateVaccin): self
    {
        $this->dateVaccin = $dateVaccin;

        return $this;
    }

    public function getAnimaux(): ?Animaux
    {
        return $this->animaux;
    }

    public function setAnimaux(?Animaux $animaux): self
    {
        $this->animaux = $animaux;

        return $this;
    }
}
