<?php

namespace App\Entity;

use App\Repository\ParcelleRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use ApiPlatform\Core\Annotation\ApiResource;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ParcelleRepository::class)]
#[ApiResource()]
class Parcelle
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $nom = null;

    #[ORM\Column(nullable: true)]
    private ?float $taille = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $gps = null;

    #[ORM\OneToMany(mappedBy: 'parcelle', targetEntity: Recolte::class)]
    private Collection $recolte;

    #[ORM\ManyToOne(inversedBy: 'parcelles')]
    private ?TypeCulture $Type = null;

    public function __construct()
    {
        $this->recolte = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(?string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getTaille(): ?float
    {
        return $this->taille;
    }

    public function setTaille(?float $taille): self
    {
        $this->taille = $taille;

        return $this;
    }

    public function getGps(): ?string
    {
        return $this->gps;
    }

    public function setGps(?string $gps): self
    {
        $this->gps = $gps;

        return $this;
    }

    /**
     * @return Collection<int, Recolte>
     */
    public function getRecolte(): Collection
    {
        return $this->recolte;
    }

    public function addRecolte(Recolte $recolte): self
    {
        if (!$this->recolte->contains($recolte)) {
            $this->recolte->add($recolte);
            $recolte->setParcelle($this);
        }

        return $this;
    }

    public function removeRecolte(Recolte $recolte): self
    {
        if ($this->recolte->removeElement($recolte)) {
            // set the owning side to null (unless already changed)
            if ($recolte->getParcelle() === $this) {
                $recolte->setParcelle(null);
            }
        }

        return $this;
    }

    public function getType(): ?TypeCulture
    {
        return $this->Type;
    }

    public function setType(?TypeCulture $Type): self
    {
        $this->Type = $Type;

        return $this;
    }
}
