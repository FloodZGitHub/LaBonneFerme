<?php

namespace App\Entity;

use App\Repository\RecolteRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: RecolteRepository::class)]
class Recolte
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: Types::DATE_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $dateRecolte = null;

    #[ORM\Column(nullable: true)]
    private ?float $rendement = null;

    #[ORM\Column(nullable: true)]
    private ?float $poidsTotal = null;

    #[ORM\ManyToOne(inversedBy: 'recolte')]
    private ?Parcelle $parcelle = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDateRecolte(): ?\DateTimeInterface
    {
        return $this->dateRecolte;
    }

    public function setDateRecolte(?\DateTimeInterface $dateRecolte): self
    {
        $this->dateRecolte = $dateRecolte;

        return $this;
    }

    public function getRendement(): ?float
    {
        return $this->rendement;
    }

    public function setRendement(?float $rendement): self
    {
        $this->rendement = $rendement;

        return $this;
    }

    public function getPoidsTotal(): ?float
    {
        return $this->poidsTotal;
    }

    public function setPoidsTotal(?float $poidsTotal): self
    {
        $this->poidsTotal = $poidsTotal;

        return $this;
    }

    public function getParcelle(): ?Parcelle
    {
        return $this->parcelle;
    }

    public function setParcelle(?Parcelle $parcelle): self
    {
        $this->parcelle = $parcelle;

        return $this;
    }
}
