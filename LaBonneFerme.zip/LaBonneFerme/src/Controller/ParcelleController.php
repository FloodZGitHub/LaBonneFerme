<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Parcelle;
use App\Entity\TypeCulture;
use App\Form\AjoutParcelleType;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class ParcelleController extends AbstractController
{
    #[Route('/ajout-parcelle', name: 'AjoutParcelle')]
    public function parcelle(Request $request, ManagerRegistry $doctrine): Response
    {
        $parcelle = new Parcelle();
        $typecultureid = new TypeCulture();
        $form = $this->createForm(AjoutParcelleType::class, $parcelle);
        if($request->isMethod('POST')){
            $form->handleRequest($request);
             
            if ($form->isSubmitted()&&$form->isValid()){
                $typecultureid = $doctrine->getRepository(TypeCulture::class)->find(1);
                $parcelle->setType($typecultureid);
                $em = $doctrine->getManager(); 
                $em->persist($parcelle);
                //var_dump($parcelle);
                dump($parcelle);
                $em->flush();
                $this->addFlash('notice','Données envoyé');
                //return $this->redirectToRoute('AjoutParcelle');
            }
        }

        return $this->render('parcelle/ajout.html.twig', [
            'form' => $form->createView()
        ]);
    }

    #[Route('/vos-parcelles', name: 'vos-parcelles')]
    public function VosParcelles(ManagerRegistry $doctrine, Request $request): Response
    {
        $repoParcelle = $doctrine->getRepository(Parcelle::class);
        $parcelles = $repoParcelle->findAll();
        $parcelleId = (int) ($request->query->get('id'));
        $parcelle = $doctrine->getRepository(Parcelle::class);

        if ($request->get('suppparcelle')!=null){
            $parcelle = $parcelle->find($request->get('suppparcelle'));
            if($parcelle!=null){
                $doctrine->getManager()->remove($parcelle);
                $doctrine->getManager()->flush();
            }
            return $this->redirectToRoute('vos-parcelles');
        }

        return $this->render('parcelle/vos-parcelles.html.twig', [
           'parcelles' => $parcelles
        ]);
    } 

}
