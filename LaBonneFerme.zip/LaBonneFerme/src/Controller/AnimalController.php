<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use App\Entity\Animaux;
use App\Entity\Vaccin;
use App\Entity\Maladie;
use Doctrine\Persistence\ManagerRegistry;
use App\Form\AjoutMaladieType;
use App\Form\AjoutVaccinType;
use App\Form\AjoutAnimalType;

class AnimalController extends AbstractController
{
    #[Route('/animaux', name: 'app_animal')]
    public function index(Request $request, ManagerRegistry $doctrine): Response
    {
        $animaux = $doctrine->getRepository(Animaux::class)->findBy(array(),array('id'=>'ASC'));
        
        if ($request->get('supanimal')!=null){
            $animaux = $doctrine->getRepository(Animaux::class);
            $animal = $animaux->find($request->get('idAnimal'));
            if($animal!=null){
                $doctrine->getManager()->remove($animal);
                $doctrine->getManager()->flush();
            }
            return $this->redirectToRoute('app_animal');
        }

        
        
        return $this->render('animal/index.html.twig', [
            'animaux'=>$animaux
        ]);

        
    }

    #[Route('/ajout-animal', name: 'AjoutAnimal')]
    public function ajoutAnimal(ManagerRegistry $doctrine, Request $request): Response
    {
        $animal = new Animaux();
        $form = $this->createForm(AjoutAnimalType::class, $animal);
        
        if($request->isMethod('POST')){
            $form->handleRequest($request);
            if ($form->isSubmitted()&&$form->isValid()){
                $em = $doctrine->getManager(); 
                $em->persist($animal);
                $em->flush();
                $this->addFlash('notice','Données envoyé');
                return $this->redirectToRoute('app_animal');
            }
        }

        return $this->render('animal/ajouter-animal.html.twig', [
            'controller_name' => 'AnimalController',
            'form' => $form->createView()
        ]);
    }

    #[Route('/ajout-vaccin', name: 'AjoutVaccin')]
    public function ajoutVaccin(ManagerRegistry $doctrine, Request $request): Response
    {
        $animalId = (int) ($request->query->get('id'));
        $animal = $doctrine->getRepository(Animaux::class)->find($animalId);
        $vaccin = new Vaccin();
        $vaccin->setAnimaux($animal);

        $form = $this->createForm(AjoutVaccinType::class, $vaccin);
    
        if($request->isMethod('POST')){
            $form->handleRequest($request);
            if ($form->isSubmitted()&&$form->isValid()){
                $em = $doctrine->getManager(); 
                $em->persist($vaccin);
                $em->flush();
                $this->addFlash('notice','Données envoyé');
                return $this->redirectToRoute('app_animal');
            }
        }


        return $this->render('animal/ajouter-vaccin.html.twig', [
            'controller_name' => 'AnimalController',
            'form' => $form->createView(),
            'animalId' => $animal
        ]);
    }

    #[Route('/ajout-maladie', name: 'AjoutMaladie')]
    public function ajoutMaladie(ManagerRegistry $doctrine, Request $request): Response
    {
        $animalId = (int) ($request->query->get('id'));
        $animal = $doctrine->getRepository(Animaux::class)->find($animalId);
        $maladie = new Maladie();
        $maladie->setAnimaux($animal);
        $form = $this->createForm(AjoutMaladieType::class, $maladie);
        if($request->isMethod('POST')){
            $form->handleRequest($request);
            if ($form->isSubmitted()&&$form->isValid()){
                $em = $doctrine->getManager(); 
                $em->persist($maladie);
                $em->flush();
                $this->addFlash('notice','Données envoyé');
                return $this->redirectToRoute('app_animal');
            }
        }

        return $this->render('animal/ajouter-maladie.html.twig', [
            'form' => $form->createView(),
            'animalId' => $animal
        ]);
    }
    
    #[Route('/details-animal', name: 'DetailsAnimal')]
    public function detailsAnimal(ManagerRegistry $doctrine, Request $request): Response
    {
        $animalId = (int) ($request->query->get('id'));
        $animal = $doctrine->getRepository(Animaux::class)->find($animalId);
        $maladies = $doctrine->getRepository(Maladie::class);
        $vaccin = $doctrine->getRepository(vaccin::class);


        if ($request->get('suppmaladie')!=null){
            $maladie = $maladies->find($request->get('idMaladie'));
            if($maladie!=null){
                $doctrine->getManager()->remove($maladie);
                $doctrine->getManager()->flush();
            }
            return $this->redirectToRoute('DetailsAnimal');
        }



      
        if ($request->get('suppvaccin')!=null){
            $vaccin = $vaccin->find($request->get('suppvaccin'));
            if($vaccin!=null){
                $doctrine->getManager()->remove($vaccin);
                $doctrine->getManager()->flush();
            }
            return $this->redirectToRoute('DetailsAnimal');
        }


        return $this->render('animal/details-animal.html.twig', [
            'animal'=>$animal,
        ]);
    }
}
