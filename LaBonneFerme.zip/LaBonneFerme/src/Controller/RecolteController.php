<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Persistence\ManagerRegistry;

class RecolteController extends AbstractController
{
    #[Route('/recolte', name: 'app_recolte')]
    public function index(): Response
    {
        return $this->render('recolte/index.html.twig', [
            'controller_name' => 'RecolteController',
        ]);
    }

    #[Route('/recolte/{idParcelle}', name: 'app_add_recolte')]
    public function addRecolte(Request $request, ManagerRegistry $doctrine, int $idParcelle): Response
    {
        $recolte  = new Recolte();
        $form = $this->createForm(AddRecolteType::class, $recolte);
        
        if($request->isMethod('POST')){
            $form->handleRequest($request);
            if ($form->isSubmitted() && $form->isValid()){
                $em = $doctrine->getManager(); 
                $em->persist($recolte);
                $em->flush();
            }
        }

        return $this->render('recolte/index.html.twig', [
            'form' => $form->createView(),
        ]);
    }
}
