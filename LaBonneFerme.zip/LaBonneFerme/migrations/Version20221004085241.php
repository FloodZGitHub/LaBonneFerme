<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20221004085241 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE recolte ADD parcelle_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE recolte ADD CONSTRAINT FK_3433713C4433ED66 FOREIGN KEY (parcelle_id) REFERENCES parcelle (id)');
        $this->addSql('CREATE INDEX IDX_3433713C4433ED66 ON recolte (parcelle_id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE recolte DROP FOREIGN KEY FK_3433713C4433ED66');
        $this->addSql('DROP INDEX IDX_3433713C4433ED66 ON recolte');
        $this->addSql('ALTER TABLE recolte DROP parcelle_id');
    }
}
