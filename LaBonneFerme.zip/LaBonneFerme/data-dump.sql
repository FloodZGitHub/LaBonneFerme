-- MySQL dump 10.19  Distrib 10.3.36-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: dblabonneferme
-- ------------------------------------------------------
-- Server version	10.3.36-MariaDB-0+deb10u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `animaux`
--

DROP TABLE IF EXISTS `animaux`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `animaux` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifiant` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `poids` double DEFAULT NULL,
  `sexe` tinyint(1) NOT NULL,
  `date_naissance` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `animaux`
--

LOCK TABLES `animaux` WRITE;
/*!40000 ALTER TABLE `animaux` DISABLE KEYS */;
INSERT INTO `animaux` VALUES (1,'23659',500,0,'2020-10-14'),(2,'789416549',750,1,NULL);
/*!40000 ALTER TABLE `animaux` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctrine_migration_versions`
--

DROP TABLE IF EXISTS `doctrine_migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctrine_migration_versions`
--

LOCK TABLES `doctrine_migration_versions` WRITE;
/*!40000 ALTER TABLE `doctrine_migration_versions` DISABLE KEYS */;
INSERT INTO `doctrine_migration_versions` VALUES ('DoctrineMigrations\\Version20221004084435','2022-10-04 10:44:48',14718),('DoctrineMigrations\\Version20221004084710','2022-10-04 10:47:19',17687),('DoctrineMigrations\\Version20221004085039','2022-10-04 10:50:49',1319),('DoctrineMigrations\\Version20221004085241','2022-10-04 10:52:49',1280),('DoctrineMigrations\\Version20221004085736','2022-10-04 10:57:53',1182),('DoctrineMigrations\\Version20221004090041','2022-10-04 11:01:04',384);
/*!40000 ALTER TABLE `doctrine_migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maladie`
--

DROP TABLE IF EXISTS `maladie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `maladie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `animaux_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ADC4024BA9DAECAA` (`animaux_id`),
  CONSTRAINT `FK_ADC4024BA9DAECAA` FOREIGN KEY (`animaux_id`) REFERENCES `animaux` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maladie`
--

LOCK TABLES `maladie` WRITE;
/*!40000 ALTER TABLE `maladie` DISABLE KEYS */;
/*!40000 ALTER TABLE `maladie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parcelle`
--

DROP TABLE IF EXISTS `parcelle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parcelle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taille` double DEFAULT NULL,
  `gps` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C56E2CF6C54C8C93` (`type_id`),
  CONSTRAINT `FK_C56E2CF6C54C8C93` FOREIGN KEY (`type_id`) REFERENCES `type_culture` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parcelle`
--

LOCK TABLES `parcelle` WRITE;
/*!40000 ALTER TABLE `parcelle` DISABLE KEYS */;
INSERT INTO `parcelle` VALUES (1,'parcelle test',23,'50.908771148810104, 2.0214947351909114',1),(5,'hhfkdsj',56,'hjfkdshkj',NULL);
/*!40000 ALTER TABLE `parcelle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recolte`
--

DROP TABLE IF EXISTS `recolte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recolte` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_recolte` date DEFAULT NULL,
  `rendement` double DEFAULT NULL,
  `poids_total` double DEFAULT NULL,
  `parcelle_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_3433713C4433ED66` (`parcelle_id`),
  CONSTRAINT `FK_3433713C4433ED66` FOREIGN KEY (`parcelle_id`) REFERENCES `parcelle` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recolte`
--

LOCK TABLES `recolte` WRITE;
/*!40000 ALTER TABLE `recolte` DISABLE KEYS */;
/*!40000 ALTER TABLE `recolte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `type_culture`
--

DROP TABLE IF EXISTS `type_culture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `type_culture` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `type_culture`
--

LOCK TABLES `type_culture` WRITE;
/*!40000 ALTER TABLE `type_culture` DISABLE KEYS */;
INSERT INTO `type_culture` VALUES (1,'Blé'),(2,'Maïs\r\n'),(3,'lin'),(4,'pommes de terre '),(5,'orge'),(6,'betteraves à sucre');
/*!40000 ALTER TABLE `type_culture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:json)',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649F85E0677` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Test','[]','$2y$13$oaMrHzj9BRKR931BDxOiZ.l/xW5nqZV0vHXkcHyV6uXLYjKFJ0iX6'),(2,'coucou','[]','$2y$13$j0vjjsEjMuQDnp0GHzDGDOr1XqSqI7Go5MVSTbIeJxCbpp.o5BYhq'),(3,'paul','[]','$2y$13$cF5VOEGoeyGOeU6027k7rOeu6inlXzdejsdpeTc.rc8v84Kc0jluW'),(4,'FloodZ','[]','$2y$13$/lo2VV1Q//Oky4lW5M8cAOhhOPzr0/loYnAgOSSK2qPsW3EWqqQza'),(5,'floodzagriculture','[]','$2y$13$VXI2S/Jmhd1DYQmwUoYituRWfxXiU0gvP1haEn/DHoqX3/8G.Q9b6');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vaccin`
--

DROP TABLE IF EXISTS `vaccin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vaccin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_vaccin` date DEFAULT NULL,
  `animaux_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B5DCA0A7A9DAECAA` (`animaux_id`),
  CONSTRAINT `FK_B5DCA0A7A9DAECAA` FOREIGN KEY (`animaux_id`) REFERENCES `animaux` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vaccin`
--

LOCK TABLES `vaccin` WRITE;
/*!40000 ALTER TABLE `vaccin` DISABLE KEYS */;
/*!40000 ALTER TABLE `vaccin` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-05  9:36:41
